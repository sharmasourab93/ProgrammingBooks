#!/usr/bin/bash 

### Scope of the variable 
