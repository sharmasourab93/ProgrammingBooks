#!/usr/bin/bash 

### Variable Values Assignment ###
comp=CTL
echo $comp

# Using Unset Command to unset the comp 
# variable
unset comp 

# Unset is reset within the ${ }
echo "Assigning values ${comp:=10}"


