#!/usr/bin/bash 

### Executing Shell Variable
### And Shell commands 

# Assign a command enclose within ` ` 
currdir=`pwd` # Current Syntax

# currdir = `pwd` # Adding Space wrongs 
		  # the syntax


# This assignment method is wrong
#year = 2010
#echo Printing $year



# This assignment method is wrong
#year =2010
#echo Printing year $year again

# This method of assignment is correct
year=2011
echo Printing year $year again


## String should be assigned under double quotes

date="01 May 2019"

echo $date

# This string assignment method is wrong 

#date = 01 May 2019
