#!/usr/bin/bash 

export project=Automation
