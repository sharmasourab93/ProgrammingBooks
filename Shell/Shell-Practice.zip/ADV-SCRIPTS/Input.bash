#!/usr/bin/bash

echo "Enter the config file name:"
read conf 

echo "CONFIG set to: ${conf:=default}"

