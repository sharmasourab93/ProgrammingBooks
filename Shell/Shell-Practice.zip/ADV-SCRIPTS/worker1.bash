#!/usr/bin/bash

echo "$0 - $comp"

## Invoke worker 1 
 

#bash worker2.bash 
