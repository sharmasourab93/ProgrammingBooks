#!/usr/bin/bash

export comp=ctl 
echo $comp 


## The scope of the company variable will be available to work1.bash

export comp=ctl 
echo $comp 

#Invoke worker1.bash
bash worker1.bash 



