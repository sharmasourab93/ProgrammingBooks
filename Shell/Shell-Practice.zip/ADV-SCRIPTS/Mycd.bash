#!/usr/bin/bash

echo "Current Path: `pwd` "
cd /tmp
echo "Current Path" `pwd`"
