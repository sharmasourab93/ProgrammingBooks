#!/usr/bin/bash 

read -p "Enter 2 numbers:" n1 n2 

if test $n1 -gt $n2 

then
     echo "$n1 > $n2"
fi 

