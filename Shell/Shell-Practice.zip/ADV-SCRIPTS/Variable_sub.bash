#!/usr/bin/bash

comp=CTL
comp1=CISCO
echo "Welcome to $comp"
echo "Welcome to $comp1"
## Restricting variable names 
echo "Welcome to ${comp}1"



