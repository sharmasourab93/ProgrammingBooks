#!/usr/bin/bash


echo "Enter comp:"
read comp 
echo "Welcome to $comp"

