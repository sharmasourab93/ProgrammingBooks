#!/usr/bin/bash 

for server in dev test 
{
	echo "Deployment started in $server"
}
