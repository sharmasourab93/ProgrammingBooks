#!/usr/bin/bash 

until [ -f "clink.dat" ]
do 
	echo "$date
